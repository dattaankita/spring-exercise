function doSomeWork() {
	
	alert("I'm doing some work!!!");
	
}